/*
*CSCE 1040 Homework 3
*Section: 002
*Name: Ijeoma Chukwuma
*UNT email: Ijeomachukwuma@my.unt.edu
*Date submitted: 4/25/2022

*File name: loan.cpp
*Description

*/
//DOESNT WORK TRIED

/*
void loan::SetLoanID(int)
{
	
}
int loan::GetLoanID()
{

}

void loan::SetLoanPatronID(int){ }
int loan::GetLoanPatronID(){}

void loan::SetLoanDueDate(string){}
string loan::GetLoanDueDate(){}

void loan::setDueDate(time_t){}
time_t getDueDate(){}

*/
