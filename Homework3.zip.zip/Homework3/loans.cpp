
/*
*CSCE 1040 Homework 3
*Section: 002
*Name: Ijeoma Chukwuma
*UNT Email: ijeomachukwuma@my.unt.edu
*Date Submitted: 25,April,2022
*File name: loans.cpp
*Description: loans collection function thatll allow to check out a book
check in a book, list all overdue books, like all books for a patron,
recheck a book, and edit a loan, and report lost


*/
/*
void loans::PrintOverdue(){}
void loans::PrintPatronBooks(){}
void loans::EditLoan(){}
void loans::ReportLost(){}
void loans::recheckbook(bool){}

COULD NOT GET TOI WORK
*/




