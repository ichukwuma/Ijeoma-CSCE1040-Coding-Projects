void bubble(student *array[], int size);
