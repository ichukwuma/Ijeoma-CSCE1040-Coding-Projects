typedef struct student_info {
  char  *first;
  char  *last;
  int   exam1;
  int   exam2;
  int   exam3;
  float mean;
} student;
